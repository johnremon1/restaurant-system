package advanced_programming_project;

public class Drink extends MenueItem {
	
	String size ;
	
	

	public Drink(String name, double price, String describtion, int id, String size) {
		super(name, price, describtion, id);
		this.size = size;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
	@Override //this is applying polymorphism 
	public double CalculatPrice() {
		
	   return super.getPrice();
	
	}
	
	

}
