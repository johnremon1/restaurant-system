package advanced_programming_project;

public class CashPayment extends Payment {
	
	public CashPayment(int orderId, String paymentMethod, double amount_paid) {
		super(orderId, paymentMethod, amount_paid);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void processPayment() {
		System.out.println("CashPayment is processed");
		
	}

}
