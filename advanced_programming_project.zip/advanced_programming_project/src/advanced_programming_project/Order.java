package advanced_programming_project;


import java.util.ArrayList;

public class Order implements Discountable {
	private ArrayList<MenueItem> items ;
	
	public Order() {
		
	}


	
	
	public Order(ArrayList<MenueItem> items ) {

		this.items = items;
	
	}

	public ArrayList<MenueItem> getItems() {
		return items;
	}


	public void setItems(ArrayList<MenueItem> items) {
		this.items = items;
	}





	public void addItem (MenueItem item , int quantity)
	{
		
		int i = 0 ;
		for (i=0 ; i<quantity ; i++)
		{
			items.add(item);
		}
	}
	
	
	public double calculateTotalPrice()
	{
		 double totalPrice = 0.0;
	        for (MenueItem item : items) {
	            totalPrice += item.CalculatPrice();  // Polymorphic behavior
	        }
		
		return totalPrice ;

	}




	@Override
	public double applyDiscount(double amount) {
		
		return calculateTotalPrice() - amount;
	}
	
	/*
	@Override
	public double applyDiscount(double amount) {
		if (amount > totalPrice) {
			throw  new IllegalAccessException("the dicount is bigger than the total price ");
		}
		else
		{

			totalPrice = totalPrice - amount ;
		}

		return totalPrice;
	}
	*/
	/*
	 public void processOrder(List<MenueItem> items) {
	        double totalPrice = 0.0;
	        for (MenueItem item : items) {
	            totalPrice += item.calculatePrice();  // Polymorphic behavior
	        }

*/
}
