package advanced_programming_project;

public interface Discountable {
	
	public double  applyDiscount (double amount ); //this methods return the new price 

}
