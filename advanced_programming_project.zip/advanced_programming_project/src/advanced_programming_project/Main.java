package advanced_programming_project;


import java.util.ArrayList;
import java.util.Scanner;





public class Main {


	public static void main(String[] args) {
		Table table1 = new Table(1, true);
		Table table2 = new Table(2, true);
		Table table3 = new Table(3, true);
		Table table4 = new Table(4, true);


		int choice = 0 ;
		while(true)
		{
			System.out.println("please choose the right answer : ");
			System.out.println("1- add an order ");
			System.out.println("2- want a table");
			System.out.println("3- free a table");
			System.out.println("4- end the program ");
			Scanner input = new Scanner(System.in);
			choice  = input.nextByte();
			try {
				if (choice == 1 )
				{
					order_an_order() ;

				}
				else if (choice == 2 )
				{
					if (table1.isTableFree() == true)
					{
						System.out.println("table 1 is free you can take it");
						table1.occupyTable();
					}
					else if (table2.isTableFree() == true) {
						System.out.println("table 2 is free you can take it");
						table2.occupyTable();
					}
					else if (table3.isTableFree() == true) {
						System.out.println("table 3 is free you can take it");
						table3.occupyTable();
					}
					else if (table4.isTableFree() == true) {
						System.out.println("table 4 is free you can take it");
						table4.occupyTable();
					}
					else
					{
						System.out.println("there are no free table please wait ");
					}
				}
				else if (choice == 3)
				{
					System.out.println("please enter the table number");
					choice = input.nextByte();
					switch (choice) {
					case 1 :
						table1.freeTable();
						break ;
					case 2 :
						table2.freeTable();
						break;
					case 3 :
						table3.freeTable();
						break ;
					case 4 :
						table4.freeTable();
						break;
					default:
						throw new IllegalArgumentException("Unexpected value: " + choice);
					}

				}
				else if (choice == 4)
				{
					break ;
				}
				else 
				{
					throw new IllegalAccessException("wrong choice");
				}

			}
			catch (Exception e) {
				System.out.println( e);
			}


		}

	}


	public static void order_an_order() {
		ArrayList<MenueItem> items = new ArrayList<MenueItem>();
		MenueItem item1 = new FoodItem("beaf burger", 66 ,"beaf burger with cheese ", 1, "Main Courses");
		MenueItem item2 = new FoodItem("Calamari", 50 ," Lightly fried squid rings served with marinara sauce and lemon wedge ", 2, "Appetizers");
		MenueItem item3 = new FoodItem("Chicken Wings", 80 ,"Crispy fried or baked chicken wings tossed in your choice of sauce (e.g., buffalo, BBQ, teriyaki).", 3, "Appetizers");
		MenueItem item4 = new FoodItem("Chicken Parmesan", 100 ,"Breaded and fried chicken breast topped with marinara sauce and melted mozzarella cheese, served with pasta.", 4 , "Main Courses");
		MenueItem item5 = new FoodItem("Pasta Primavera", 60 ,"Seasonal vegetables tossed with pasta in a light cream sauce, topped with parmesan cheese", 5 , "Main Courses");
		MenueItem item6 = new FoodItem("Chocolate Cake", 45 ,"Rich and decadent chocolate cake with chocolate frosting ", 6 , "Desserts");
		MenueItem item7 = new FoodItem("Fruit Salad", 30 ,"Seasonal fresh fruits with a light honey or yogurt dressing ", 7 , "Desserts");
		MenueItem item8 = new Drink("Coca-Cola", 10 , "big Coca-Cola", 8 , "big");
		MenueItem item9 = new Drink("Orange juice", 15 , "big Orange juice", 9 , "big");
		MenueItem item10 = new Drink("Coca-Cola", 7 , "small Coca-Cola", 10 , "small");
		MenueItem item11 = new Drink("Orange juice", 10 , "medimum Orange juice", 11 , "medium");
		double total_price = 0 ;
		int choice ;
		double dicount_amount = 0 ;
		int flag = 0 ;
		Scanner input = new Scanner(System.in);
		while (true)
		{
			if (flag == 1)
			{
				break ;
			}

			System.out.println("please choose an  answer : ");
			System.out.println("1- add a Main Courses ");
			System.out.println("2- add an Appetizers ");
			System.out.println("3- add a Desserts ");
			System.out.println("4- add a drink ");
			System.out.println("5- end order ");

			choice = input.nextByte();
			switch (choice) {

			case 1 :
				System.out.println("please choose an  answer from the main Courses : ");
				System.out.println("1- beaf burger  66 $ ");
				System.out.println("2- Chicken Parmesan 100 $ ");
				System.out.println("3- Pasta Primavera 60 $ ");
				choice = input.nextByte();
				switch (choice) {

				case 1 :
					System.out.println("beaf burger  with cheese ");//id 1 
					items.add(item1);
					break ;
				case 2 :
					System.out.println("Breaded and fried chicken breast topped with marinara sauce and melted mozzarella cheese, served with pasta.");//id 4 
					items.add(item4);
					break ;
				case 3 :
					System.out.println("Seasonal vegetables tossed with pasta in a light cream sauce, topped with parmesan cheese");//id 5
					items.add(item5);
					break ;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);

				}

				break ;
			case 2 :
				System.out.println("please choose an  answer from Appetizers : ");
				System.out.println("1- Calamari 50 $ "); //id 2
				System.out.println("2- Chicken Wings 80 $ "); // id 3
				choice = input.nextByte();
				switch (choice)
				{
				case 1 :
					System.out.println("you choosed Calamari description : Lightly fried squid rings served with marinara sauce and lemon wedge   "); //id 2
					items.add(item2);
					break;
				case 2 :
					System.out.println("you choosed Chicken Wings description : Crispy fried or baked chicken wings tossed in your choice of sauce (e.g., buffalo, BBQ, teriyaki)."); //id 3
					items.add(item3);
					break ;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);

				}
				break ;
			case 3 :
				System.out.println("please choose an  answer from desirt : ");
				System.out.println("1- Chocolate Cake 45 $ "); //id 6
				System.out.println("2- friut salad 30 $ "); // id 7
				choice = input.nextByte();
				switch (choice)
				{
				case 1 :
					System.out.println("Chocolate Cake description : Rich and decadent chocolate cake with chocolate frosting");
					items.add(item6);
					break ;
				case 2:
					System.out.println("friut salad description : Seasonal fresh fruits with a light honey or yogurt dressing");
					items.add(item7);
					break ;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);

				}
				break ;
			case 4:
				System.out.println("please choose an  answer from drinks : ");
				System.out.println("1- big coca cola 10 $"); 
				System.out.println("2- big Orange juice 15 $ "); 
				System.out.println("3- small coca cola 7 & "); 
				System.out.println("4- small Orange juice 10 & "); 
				choice = input.nextByte();
				switch (choice)
				{
				case 1: 
					items.add(item8);
					break ;
				case 2: 
					items.add(item9);
					break ;
				case 3: 
					items.add(item10);
					break ;
				case 4: 
					items.add(item11);
					break ;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);

				}
				break; 

			case 5 :

				System.out.println("5- end order ");
				Order order = new Order(items);
				System.out.print("the order price is : ");
				System.out.println(order.calculateTotalPrice());
				flag = 1 ;
				total_price = order.calculateTotalPrice();
				
				System.out.println("do you have a discount ");
				System.out.println("1 - yes ");
				System.out.println("2- no");
				choice = input.nextByte();
				switch (choice) {
				case 1:
					System.out.println("discount amount ");
					dicount_amount  = input.nextDouble();
					try
					{
						if (dicount_amount > total_price)
						{
							throw new IllegalAccessException("the dicount is bigger than the order price make sure of the dicount");
						}
						else
						{
							total_price =order.applyDiscount(dicount_amount);
							System.out.println("the order price after dicount : " + total_price );	
						}
					}
					catch (Exception e) {
					System.out.println(e);
					}
					break ;
				case 2:
					System.out.println("the order price is : " + total_price);
					break ;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);
				}
				System.out.println("how you want to pay");
				System.out.println("1- cash payment ");
				System.out.println("2- credit payment ");
				choice = input.nextByte();
				switch (choice)
				{
				case 1:
					Payment payment1 = new CashPayment(0, "cash payment",total_price);
					payment1.processPayment();
					break;
				case 2:
					Payment payment2 = new CreditCardPayment(0, "cash payment",total_price);
					payment2.processPayment();
					break;
				default:
					throw new IllegalArgumentException("Unexpected value: " + choice);
				}
				break ;

			}

		}
	}

}

