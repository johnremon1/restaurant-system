package advanced_programming_project;

public class FoodItem extends MenueItem{
	private String category ;

	
	public FoodItem(String name, double price,String describtion, int id,String category) {
		super(name,  price,  describtion, id);
		this.category = category;
	}
	
	

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
	@Override //this is applying polymorphism 
	public double CalculatPrice() {
		return super.getPrice() ;
		
		
	}

	
	
	
	
	

}
