package advanced_programming_project;

public abstract class Payment {
	
	private int orderId ;
	private String paymentMethod ;
	private double amount_paid ;
	
	
	public Payment(int orderId, String paymentMethod, double amount_paid) {
		super();
		this.orderId = orderId;
		this.paymentMethod = paymentMethod;
		this.amount_paid = amount_paid;
	}
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public double getAmount_paid() {
		return amount_paid;
	}
	public void setAmount_paid(double amount_paid) {
		this.amount_paid = amount_paid;
	}
	
	
	public abstract void processPayment();

}
