package advanced_programming_project;

public class Table {
	private final int tableNumber ;
	private boolean isAvailable ;
	
	
	public Table(int tableNumber) {
		super();
		this.tableNumber = tableNumber ;
		
	}


	public Table(int tableNumber, boolean isAvailable) {
		super();
		this.tableNumber = tableNumber;
		this.isAvailable = isAvailable;
	}


	public boolean isTableFree() {
		
		return isAvailable ;	
	}
	
	
	public void occupyTable() {
		this.isAvailable = false ;	
	}
	
	public void freeTable() {
		this.isAvailable = true ;
		
	}
	

}
