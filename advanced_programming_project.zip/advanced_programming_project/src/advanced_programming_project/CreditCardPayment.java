package advanced_programming_project;

public class CreditCardPayment extends Payment {
	
	
	public CreditCardPayment(int orderId, String paymentMethod, double amount_paid) {
		super(orderId, paymentMethod, amount_paid);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void processPayment() {
		System.out.println("CreditCardPayment is processed");
		
	}

}
