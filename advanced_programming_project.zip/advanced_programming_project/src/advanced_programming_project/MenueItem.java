package advanced_programming_project;

public abstract class MenueItem {
	private String name ;//encapsulation 
	private double price ;//encapsulation 
	private String describtion ;//encapsulation 
	private int id ;//encapsulation 
	
	
	public MenueItem(String name, double price, String describtion, int id) {
		this.name = name;
		this.price = price;
		this.describtion = describtion;
		this.id = id;
	}

	public abstract double CalculatPrice();
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescribtion() {
		return describtion;
	}

	public void setDescribtion(String describtion) {
		this.describtion = describtion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
